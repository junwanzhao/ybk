export const courseList = [
	{
			courseId: 1,
			courseClass: "软件2242 Web2班",
			courseNo: "2942577",
			courseName: "后端工程开发",
			courseCover: "/static/images/SpringBoot.jpg",
			courseTeacher: {
				name: "许莫淇",
				avatar: "/static/images/mqxu.jpg",
			},
			semester: "2022-2-23-2",
			finished: false,
			show: false,
		},
		{
			courseId: 2,
			courseClass: "软件2242 Web2班",
			courseNo: "9488275",
			courseName: "前端工程开发",
			courseCover: "/static/images/Vue.png",
			courseTeacher: {
				name: "许莫淇",
				avatar: "/static/images/mqxu.jpg",
			},
			semester: "2022-2-23-2",
			finished: false,
			show: false,
		},
		{
			courseId: 3,
			courseClass: "软件2242 Web2班",
			courseNo: "8175074",
			courseName: "Web应用开发",
			courseCover: "static/images/Web.png",
			courseTeacher: {
				name: "许莫淇",
				avatar: "/static/images/mqxu.jpg",
			},
			semester: "2022-2-23-2",
			finished: false,
			show: false,
		},
		{
			courseId: 4,
			courseClass: "软件2216",
			courseNo: "2942577",
			courseName: "Java程序设计",
			courseCover: "/static/images/Java.jpg",
			courseTeacher: {
				name: "许莫淇",
				avatar: "/static/images/mqxu.jpg",
			},
			semester: "2022-2-23-2",
			finished: false,
			show: false,
		}
]